<?php
// includes/quicky-ai-prompts-advanced.php

if (!defined('ABSPATH')) {
    exit;
}

class QuickyAIPromptsAdvanced {
    
    /**
     * PROMPTS RECETTES ULTRA-ENRICHIS
     * Storytelling + Science + Troubleshooting + Variations
     */
    public static function get_recipe_prompt_storytelling($appliance, $keyword, $custom_title, $cooking_time, $difficulty, $serves, $cuisine_type, $dietary_tags) {
        $appliance_science = self::get_appliance_science($appliance);
        $emotion_hooks = self::get_emotion_hooks($keyword, $appliance);
        $dietary_science = self::get_dietary_science($dietary_tags);
        
        return "Create an ULTRA-RICH recipe that combines storytelling, science, and practical expertise for Quicky Cooking website.

CRITICAL: Respond ONLY with valid JSON format.

STORYTELLING REQUIREMENTS:
- Start with an emotional hook that connects to real-life situations
- Include a 'why this recipe is special' story
- Add personal touches and relatable scenarios
- Create anticipation and desire for the dish

SCIENTIFIC EXPLANATION REQUIREMENTS:
- Explain WHY the cooking method works (Maillard reaction, moisture control, etc.)
- Include temperature science and timing rationale
- Explain texture/flavor development processes
- Add food safety and nutritional insights

ULTRA-DETAILED INSTRUCTIONS:
- Every step must include WHY you're doing it
- Specific sensory cues (sounds, smells, visual indicators)
- Exact timing with explanations
- Pro tips from experienced chefs

Recipe Requirements:
- Appliance: {$appliance}
- Main keyword: {$keyword}
- Custom title: " . ($custom_title ?: 'AI will generate compelling title') . "
- Target cooking time: {$cooking_time} minutes
- Difficulty level: {$difficulty}
- Serves: {$serves} people
- Cuisine type: {$cuisine_type}
- Dietary requirements: {$dietary_tags}

APPLIANCE SCIENCE:
{$appliance_science}

EMOTIONAL HOOKS TO USE:
{$emotion_hooks}

DIETARY SCIENCE:
{$dietary_science}

RESPONSE FORMAT:
{
  \"title\": \"Compelling title with emotional appeal and main keyword\",
  \"meta_description\": \"Hook description with emotional trigger + practical benefit (150-160 chars)\",
  \"excerpt\": \"One-line emotional hook that makes people want to cook this NOW (200 chars)\",
  \"storytelling_intro\": {
    \"emotional_hook\": \"Start with relatable scenario (tired after work, guests coming, etc.)\",
    \"transformation_promise\": \"What this recipe will do for them emotionally/practically\",
    \"credibility_statement\": \"Why they can trust this recipe (tested X times, etc.)\",
    \"anticipation_builder\": \"Describe the amazing end result they'll achieve\"
  },
  \"why_this_recipe_works\": {
    \"scientific_explanation\": \"Detailed explanation of cooking science behind the method\",
    \"technique_benefits\": \"Why this specific technique/appliance is superior\",
    \"flavor_development\": \"How flavors develop during cooking process\",
    \"texture_science\": \"Why texture comes out perfect with this method\"
  },
  \"prep_time\": {$cooking_time > 30 ? 15 : 10},
  \"cook_time\": {$cooking_time},
  \"total_time\": \"calculated including rest time if needed\",
  \"servings\": {$serves},
  \"difficulty\": \"{$difficulty}\",
  \"cuisine_type\": \"{$cuisine_type}\",
  \"main_content\": {
    \"ingredients_with_science\": [
      {
        \"ingredient\": \"Precise ingredient with measurement\",
        \"purpose\": \"Why this ingredient is essential for the recipe\",
        \"substitution\": \"What can replace it and how it changes the result\",
        \"quality_tips\": \"How to choose the best version of this ingredient\"
      }
    ],
    \"equipment_detailed\": [
      {
        \"equipment\": \"Essential equipment item\",
        \"why_needed\": \"Specific reason this tool is important\",
        \"alternatives\": \"What to use if you don't have it\",
        \"pro_tips\": \"How to use it like a chef\"
      }
    ],
    \"step_by_step_masterclass\": [
      {
        \"step_number\": 1,
        \"action\": \"Detailed action with specific {$appliance} settings\",
        \"why_this_step\": \"Scientific/practical reason for this step\",
        \"sensory_cues\": \"What to look for: sounds, smells, visual changes\",
        \"timing_explanation\": \"Why this specific timing matters\",
        \"common_mistakes\": \"What people usually do wrong here\",
        \"pro_tip\": \"Chef-level insight for this step\",
        \"troubleshooting\": \"What to do if something goes wrong\"
      }
    ],
    \"troubleshooting_comprehensive\": [
      {
        \"problem\": \"Specific issue that commonly occurs\",
        \"cause\": \"Root cause explanation\",
        \"solution\": \"Step-by-step fix\",
        \"prevention\": \"How to avoid this next time\"
      }
    ],
    \"variations_and_adaptations\": [
      {
        \"variation_name\": \"Creative variation name (e.g., 'Mediterranean Magic')\",
        \"changes\": \"Specific ingredient/technique changes\",
        \"dietary_benefit\": \"Who this variation serves (keto, vegan, etc.)\",
        \"flavor_profile\": \"How the taste changes\",
        \"difficulty_change\": \"If complexity changes\"
      }
    ],
    \"storage_and_meal_prep\": {
      \"storage_instructions\": \"Detailed storage with timeframes\",
      \"reheating_best_practices\": \"How to reheat to maintain quality\",
      \"make_ahead_tips\": \"What can be prepped in advance\",
      \"freezing_guide\": \"If/how to freeze and for how long\",
      \"leftover_transformations\": \"Creative ways to use leftovers\"
    },
    \"nutrition_deep_dive\": {
      \"health_benefits\": \"Specific nutritional advantages\",
      \"dietary_considerations\": \"Important notes for special diets\",
      \"ingredient_nutrition_highlights\": \"Star nutrients from key ingredients\",
      \"healthier_modifications\": \"How to make it even healthier\"
    }
  },
  \"expert_insights\": {
    \"chef_secrets\": [\"Professional techniques that make a difference\"],
    \"restaurant_vs_home\": \"How this compares to restaurant versions\",
    \"cultural_context\": \"Traditional background or modern adaptation story\",
    \"seasonal_notes\": \"Best times to make this and why\"
  },
  \"seo_optimized_sections\": {
    \"faq_for_featured_snippets\": [
      {
        \"question\": \"How long to cook {$keyword} in {$appliance}?\",
        \"answer\": \"Complete answer with timing, temperature, and key indicators\"
      },
      {
        \"question\": \"Why is my {$keyword} not crispy/tender/perfect?\",
        \"answer\": \"Troubleshooting answer with multiple solutions\"
      },
      {
        \"question\": \"Can I make {$keyword} without {$appliance}?\",
        \"answer\": \"Alternative methods with timing adjustments\"
      },
      {
        \"question\": \"What goes well with {$keyword}?\",
        \"answer\": \"Pairing suggestions with reasons why they work\"
      }
    ],
    \"related_searches_content\": [
      \"Content addressing 'best {$appliance} for {$keyword}'\",
      \"Content addressing '{$keyword} recipe variations'\",
      \"Content addressing '{$keyword} nutrition facts'\",
      \"Content addressing 'how to store {$keyword}'\",
      \"Content addressing '{$keyword} meal prep ideas'\"
    ],
    \"long_tail_keywords_natural\": [
      \"easy {$keyword} recipe for beginners\",
      \"healthy {$keyword} {$appliance} recipe\",
      \"quick {$keyword} recipe {$cooking_time} minutes\",
      \"best {$keyword} recipe for {$cuisine_type}\",
      \"crispy {$keyword} {$appliance} recipe\"
    ]
  },
  \"engagement_elements\": {
    \"success_stories\": [\"Brief testimonial-style examples of success\"],
    \"common_questions_addressed\": [\"Anticipated questions with inline answers\"],
    \"motivation_boosters\": [\"Encouraging statements for nervous cooks\"],
    \"time_saving_hacks\": [\"Pro tips to make it even faster/easier\"]
  },
  \"nutrition_per_serving\": {
    \"calories\": \"accurate estimate\",
    \"protein\": \"amount with percentage daily value\",
    \"carbs\": \"amount with net carbs if relevant\",
    \"fat\": \"amount with breakdown of types\",
    \"fiber\": \"amount with digestive benefits note\",
    \"key_nutrients\": \"standout vitamins/minerals with benefits\"
  },
  \"recipe_tags_semantic\": [
    \"Primary appliance tag\",
    \"Cooking method tags\",
    \"Dietary tags\",
    \"Difficulty tags\",
    \"Time-based tags\",
    \"Cuisine tags\",
    \"Occasion tags\"
  ]
}

Make this recipe so detailed and engaging that readers feel confident, excited, and empowered to create something amazing. Every element should serve both the cook and search engines perfectly!";
    }

    /**
     * PROMPTS GUIDES D'ACHAT ULTRA-PROFESSIONNELS
     * Tests réels + Données + Crédibilité + Témoignages
     */
    public static function get_buying_guide_prompt_professional($category, $budget_range, $target_audience, $key_features) {
        $testing_methodology = self::get_testing_methodology($category);
        $credibility_elements = self::get_credibility_elements();
        $comparison_frameworks = self::get_comparison_frameworks($category);
        
        return "Create a PROFESSIONAL, CREDIBLE buying guide that establishes expertise through real testing and detailed analysis.

CRITICAL: Respond ONLY with valid JSON format.

CREDIBILITY REQUIREMENTS:
- Establish testing methodology and expertise upfront
- Include specific testing data and measurable results
- Add authentic user testimonials and real experiences
- Provide transparent pros/cons for each recommendation

PROFESSIONAL STRUCTURE:
- Executive summary with clear recommendations
- Detailed testing methodology explanation
- Individual product deep-dives with data
- Comparison tables with objective criteria
- Practical buying advice with real-world considerations

EXPERTISE DEMONSTRATION:
- Show testing time invested and methodology
- Include specific measurements and benchmarks
- Reference industry standards and certifications
- Demonstrate knowledge of technical specifications

Guide Requirements:
- Product Category: {$category}
- Budget Range: {$budget_range}
- Target Audience: {$target_audience}
- Key Features Focus: {$key_features}

TESTING METHODOLOGY FOR {$category}:
{$testing_methodology}

CREDIBILITY ELEMENTS TO INCLUDE:
{$credibility_elements}

COMPARISON FRAMEWORKS:
{$comparison_frameworks}

RESPONSE FORMAT:
{
  \"title\": \"Best {$category} 2025: Professional Testing & Analysis [Updated]\",
  \"meta_description\": \"Professional {$category} reviews with real testing data. 6 months of testing, {$category} compared. Expert recommendations for every budget.\",
  \"excerpt\": \"Professional analysis of the best {$category} based on extensive real-world testing and measurable performance data\",
  \"credibility_establishment\": {
    \"testing_overview\": \"Comprehensive overview of testing methodology and time invested\",
    \"expertise_statement\": \"Author credentials and testing experience\",
    \"transparency_note\": \"Clear disclosure of testing process and potential conflicts\",
    \"update_commitment\": \"Promise of regular updates and re-testing\"
  },
  \"executive_summary\": {
    \"top_pick_overall\": {
      \"product_name\": \"Best overall choice\",
      \"reason\": \"Specific data-driven reason why it's the top pick\",
      \"best_for\": \"Who should buy this and why\",
      \"price_point\": \"Current price range\",
      \"key_advantage\": \"Main competitive advantage\"
    },
    \"best_budget\": {
      \"product_name\": \"Best budget choice\",
      \"reason\": \"Why it offers best value for money\",
      \"compromises\": \"What you give up vs premium options\",
      \"price_point\": \"Budget-friendly price range\"
    },
    \"best_premium\": {
      \"product_name\": \"Best premium choice\",
      \"reason\": \"What justifies the premium price\",
      \"advanced_features\": \"Premium features worth paying for\",
      \"price_point\": \"Premium price range\"
    }
  },
  \"testing_methodology_detailed\": {
    \"testing_duration\": \"How long products were tested\",
    \"testing_conditions\": \"Standardized conditions for fair comparison\",
    \"measurement_tools\": \"Equipment used for objective measurements\",
    \"test_scenarios\": [\"Real-world usage scenarios tested\"],
    \"data_collection\": \"How performance data was gathered and verified\",
    \"bias_prevention\": \"Steps taken to ensure objective testing\"
  },
  \"main_content\": {
    \"buying_factors_expert\": [
      {
        \"factor\": \"Critical buying consideration\",
        \"importance_level\": \"High/Medium/Low with explanation\",
        \"technical_details\": \"Deep technical explanation\",
        \"testing_insights\": \"What our testing revealed about this factor\",
        \"real_world_impact\": \"How this affects daily usage\",
        \"red_flags\": \"Warning signs of poor quality in this area\",
        \"sweet_spot_advice\": \"Optimal specifications for this factor\"
      }
    ],
    \"detailed_reviews_with_data\": [
      {
        \"product_name\": \"Complete product name and model\",
        \"overall_score\": \"X.X/10 with scoring breakdown\",
        \"price_current\": \"Current price with last updated date\",
        \"best_for_specific\": \"Very specific user profile who should buy this\",
        \"testing_highlights\": {
          \"performance_data\": \"Specific measured performance metrics\",
          \"durability_testing\": \"How it held up over testing period\",
          \"user_experience_notes\": \"Subjective but detailed usage experience\",
          \"comparison_vs_competitors\": \"Direct performance vs other tested models\"
        },
        \"key_features_analyzed\": [
          {
            \"feature\": \"Specific feature name\",
            \"our_take\": \"Detailed analysis based on testing\",
            \"performance_rating\": \"X/10 with explanation\",
            \"real_world_benefit\": \"Actual impact on user experience\"
          }
        ],
        \"pros_data_driven\": [\"Pros backed by testing data\"],
        \"cons_honest\": [\"Honest cons discovered during testing\"],
        \"long_term_outlook\": \"Predicted longevity and value retention\",
        \"bottom_line_verdict\": \"Clear recommendation with reasoning\",
        \"where_to_buy_best\": \"Best retailers with current pricing insights\"
      }
    ],
    \"comparison_table_comprehensive\": {
      \"methodology_note\": \"How comparison data was gathered\",
      \"headers\": [\"Product\", \"Price\", \"Key Metrics\", \"Pros\", \"Cons\", \"Best For\", \"Score\"],
      \"comparison_data\": \"Structured data for easy comparison\",
      \"scoring_explanation\": \"How overall scores were calculated\"
    },
    \"real_user_testimonials\": [
      {
        \"user_profile\": \"Real user demographic and use case\",
        \"usage_duration\": \"How long they've owned/used the product\",
        \"testimonial\": \"Authentic experience quote\",
        \"pros_mentioned\": \"What they love about it\",
        \"cons_mentioned\": \"What they wish was different\",
        \"recommendation\": \"Would they buy again/recommend?\"
      }
    ],
    \"buying_guide_practical\": {
      \"size_selection_guide\": \"Exact guidance on choosing right size\",
      \"feature_prioritization\": \"Which features matter most for different users\",
      \"timing_advice\": \"Best times to buy for deals/new models\",
      \"warranty_considerations\": \"What to look for in warranties\",
      \"setup_and_maintenance\": \"What to expect for setup and ongoing care\",
      \"future_proofing\": \"How to ensure your purchase stays relevant\"
    },
    \"common_mistakes_to_avoid\": [
      {
        \"mistake\": \"Common purchasing error\",
        \"why_people_make_it\": \"Psychology/reasoning behind the mistake\",
        \"consequences\": \"What happens when you make this mistake\",
        \"how_to_avoid\": \"Specific steps to avoid this pitfall\"
      }
    ]
  },
  \"expert_insights_advanced\": {
    \"industry_trends\": \"Current trends affecting {$category} market\",
    \"technology_evolution\": \"How {$category} technology is advancing\",
    \"price_predictions\": \"Expected price movements and best buying times\",
    \"emerging_features\": \"New features to watch for in upcoming models\",
    \"brand_analysis\": \"Insights on different manufacturers and their strengths\"
  },
  \"seo_optimized_sections\": {
    \"faq_for_featured_snippets\": [
      {
        \"question\": \"What is the best {$category} for {$target_audience}?\",
        \"answer\": \"Data-driven answer with specific recommendation and reasoning\"
      },
      {
        \"question\": \"How much should I spend on a {$category}?\",
        \"answer\": \"Budget guidance with value tiers and recommendations\"
      },
      {
        \"question\": \"What size {$category} do I need?\",
        \"answer\": \"Sizing guide with specific use cases\"
      },
      {
        \"question\": \"Are expensive {$category} worth it?\",
        \"answer\": \"Value analysis comparing budget vs premium options\"
      }
    ],
    \"related_searches_covered\": [
      \"best {$category} 2025\",
      \"cheap vs expensive {$category}\",
      \"{$category} buying guide\",
      \"{$category} reviews\",
      \"how to choose {$category}\"
    ]
  },
  \"maintenance_and_longevity\": {
    \"care_instructions\": \"How to maintain your {$category} for longevity\",
    \"common_issues\": \"Problems that develop over time and solutions\",
    \"replacement_timeline\": \"When to expect replacement need\",
    \"upgrade_path\": \"Natural upgrade progression for users\"
  },
  \"final_recommendations_by_profile\": [
    {
      \"user_profile\": \"Specific user type\",
      \"recommended_product\": \"Best choice for this profile\",
      \"reasoning\": \"Why this choice makes sense\",
      \"budget_range\": \"Expected investment\",
      \"key_benefits\": \"Main advantages for this user type\"
    }
  ]
}

Make this guide so thorough and credible that readers feel completely confident in their purchase decision and trust your expertise completely!";
    }

    /**
     * PROMPTS COMPARATIFS ULTRA-DÉTAILLÉS
     * Structure professionnelle + Critères objectifs + Verdict justifié
     */
    public static function get_comparison_prompt_detailed($product1, $product2, $comparison_focus) {
        $comparison_methodology = self::get_comparison_methodology();
        $scoring_framework = self::get_scoring_framework();
        
        return "Create a COMPREHENSIVE, OBJECTIVE comparison that provides clear winner analysis with detailed justification.

CRITICAL: Respond ONLY with valid JSON format.

COMPARISON METHODOLOGY REQUIREMENTS:
- Establish clear, objective testing criteria
- Use consistent scoring methodology across all factors
- Provide specific examples and real-world scenarios
- Include both quantitative data and qualitative insights

PROFESSIONAL STRUCTURE:
- Executive summary with clear winner
- Head-to-head analysis by category
- Real-world usage scenarios
- Value proposition analysis
- Final recommendation with reasoning

OBJECTIVITY STANDARDS:
- Present honest pros/cons for both products
- Use measurable criteria where possible
- Acknowledge subjective preferences
- Base conclusions on evidence presented

Comparison Requirements:
- Product 1: {$product1}
- Product 2: {$product2}
- Focus Areas: {$comparison_focus}

COMPARISON METHODOLOGY:
{$comparison_methodology}

SCORING FRAMEWORK:
{$scoring_framework}

RESPONSE FORMAT:
{
  \"title\": \"{$product1} vs {$product2}: Complete 2025 Comparison [Winner Revealed]\",
  \"meta_description\": \"Professional {$product1} vs {$product2} comparison. Real testing data, detailed analysis, clear winner. Which should you buy?\",
  \"excerpt\": \"Comprehensive head-to-head comparison revealing which product offers better value, performance, and features for your needs\",
  \"comparison_overview\": {
    \"products_being_compared\": \"{$product1} and {$product2}\",
    \"comparison_purpose\": \"Why these two products are worth comparing\",
    \"target_decision_makers\": \"Who this comparison helps most\",
    \"methodology_summary\": \"Brief overview of how comparison was conducted\",
    \"key_differentiators\": \"Main factors that separate these products\"
  },
  \"executive_summary\": {
    \"overall_winner\": \"Product name with margin of victory\",
    \"winner_score\": \"X.X vs X.X out of 10\",
    \"victory_margin\": \"Close/Clear/Decisive with explanation\",
    \"key_winning_factors\": [\"Top 3 factors that determined the winner\"],
    \"when_loser_wins\": \"Specific scenarios where the 'losing' product is better\",
    \"bottom_line\": \"One-sentence recommendation\"
  },
  \"products_overview\": [
    {
      \"product_name\": \"{$product1}\",
      \"current_price\": \"Current market price with date\",
      \"key_strengths\": [\"Top 3 standout strengths\"],
      \"main_weaknesses\": [\"Top 2 notable weaknesses\"],
      \"best_for\": \"Ideal user profile for this product\",
      \"unique_selling_point\": \"What makes this product special\"
    },
    {
      \"product_name\": \"{$product2}\",
      \"current_price\": \"Current market price with date\",
      \"key_strengths\": [\"Top 3 standout strengths\"],
      \"main_weaknesses\": [\"Top 2 notable weaknesses\"],
      \"best_for\": \"Ideal user profile for this product\",
      \"unique_selling_point\": \"What makes this product special\"
    }
  ],
  \"detailed_comparison_categories\": [
    {
      \"category\": \"Performance & Quality\",
      \"importance_weight\": \"High - 25% of overall score\",
      \"comparison_details\": {
        \"product1_analysis\": \"Detailed performance analysis with specific examples\",
        \"product2_analysis\": \"Detailed performance analysis with specific examples\",
        \"head_to_head_result\": \"Direct comparison with specific metrics\",
        \"real_world_impact\": \"What this means for daily usage\",
        \"winner\": \"Product name\",
        \"margin\": \"How close/decisive the victory\",
        \"reasoning\": \"Specific reasons for the winner selection\"
      },
      \"scores\": {
        \"product1_score\": \"X.X/10\",
        \"product2_score\": \"X.X/10\"
      }
    },
    {
      \"category\": \"Value for Money\",
      \"importance_weight\": \"High - 20% of overall score\",
      \"comparison_details\": {
        \"product1_analysis\": \"Value proposition analysis\",
        \"product2_analysis\": \"Value proposition analysis\",
        \"head_to_head_result\": \"Direct value comparison\",
        \"long_term_value\": \"Durability and long-term ownership costs\",
        \"winner\": \"Product name\",
        \"margin\": \"How close/decisive the victory\",
        \"reasoning\": \"Specific reasons for the winner selection\"
      },
      \"scores\": {
        \"product1_score\": \"X.X/10\",
        \"product2_score\": \"X.X/10\"
      }
    },
    {
      \"category\": \"Features & Functionality\",
      \"importance_weight\": \"Medium - 15% of overall score\",
      \"comparison_details\": {
        \"product1_analysis\": \"Feature analysis with practical benefits\",
        \"product2_analysis\": \"Feature analysis with practical benefits\",
        \"head_to_head_result\": \"Feature comparison with usage scenarios\",
        \"innovation_factor\": \"Which product offers more innovative features\",
        \"winner\": \"Product name\",
        \"margin\": \"How close/decisive the victory\",
        \"reasoning\": \"Specific reasons for the winner selection\"
      },
      \"scores\": {
        \"product1_score\": \"X.X/10\",
        \"product2_score\": \"X.X/10\"
      }
    },
    {
      \"category\": \"Ease of Use\",
      \"importance_weight\": \"Medium - 15% of overall score\",
      \"comparison_details\": {
        \"product1_analysis\": \"User experience analysis\",
        \"product2_analysis\": \"User experience analysis\",
        \"head_to_head_result\": \"Usability comparison\",
        \"learning_curve\": \"How quickly users can master each product\",
        \"winner\": \"Product name\",
        \"margin\": \"How close/decisive the victory\",
        \"reasoning\": \"Specific reasons for the winner selection\"
      },
      \"scores\": {
        \"product1_score\": \"X.X/10\",
        \"product2_score\": \"X.X/10\"
      }
    },
    {
      \"category\": \"Build Quality & Design\",
      \"importance_weight\": \"Medium - 15% of overall score\",
      \"comparison_details\": {
        \"product1_analysis\": \"Construction and design analysis\",
        \"product2_analysis\": \"Construction and design analysis\",
        \"head_to_head_result\": \"Build quality comparison\",
        \"durability_expectations\": \"Expected longevity for each product\",
        \"winner\": \"Product name\",
        \"margin\": \"How close/decisive the victory\",
        \"reasoning\": \"Specific reasons for the winner selection\"
      },
      \"scores\": {
        \"product1_score\": \"X.X/10\",
        \"product2_score\": \"X.X/10\"
      }
    },
    {
      \"category\": \"Brand & Support\",
      \"importance_weight\": \"Low - 10% of overall score\",
      \"comparison_details\": {
        \"product1_analysis\": \"Brand reputation and support analysis\",
        \"product2_analysis\": \"Brand reputation and support analysis\",
        \"head_to_head_result\": \"Brand and support comparison\",
        \"warranty_analysis\": \"Warranty terms and customer service quality\",
        \"winner\": \"Product name\",
        \"margin\": \"How close/decisive the victory\",
        \"reasoning\": \"Specific reasons for the winner selection\"
      },
      \"scores\": {
        \"product1_score\": \"X.X/10\",
        \"product2_score\": \"X.X/10\"
      }
    }
  ],
  \"real_world_scenarios\": [
    {
      \"scenario\": \"Specific usage scenario\",
      \"product1_performance\": \"How Product 1 handles this scenario\",
      \"product2_performance\": \"How Product 2 handles this scenario\",
      \"winner\": \"Which performs better in this scenario\",
      \"significance\": \"How important this scenario is for most users\"
    }
  ],
  \"comparison_table_data\": {
    \"headers\": [\"Feature/Aspect\", \"{$product1}\", \"{$product2}\", \"Winner\", \"Notes\"],
    \"rows\": [
      [\"Price\", \"$X\", \"$Y\", \"Depends on budget\", \"Value context\"],
      [\"Performance\", \"Rating\", \"Rating\", \"Winner\", \"Key differentiator\"],
      [\"Features\", \"Count/Quality\", \"Count/Quality\", \"Winner\", \"Most useful features\"],
      [\"Ease of Use\", \"Rating\", \"Rating\", \"Winner\", \"User experience notes\"],
      [\"Build Quality\", \"Rating\", \"Rating\", \"Winner\", \"Durability expectations\"],
      [\"Brand Support\", \"Rating\", \"Rating\", \"Winner\", \"Warranty/service notes\"]
    ]
  },
  \"decision_framework\": {
    \"choose_product1_if\": [
      \"Specific condition where Product 1 is better\",
      \"Another condition favoring Product 1\",
      \"Third condition for Product 1\"
    ],
    \"choose_product2_if\": [
      \"Specific condition where Product 2 is better\",
      \"Another condition favoring Product 2\",
      \"Third condition for Product 2\"
    ],
    \"neutral_factors\": [\"Factors where products are essentially equal\"]
  },
  \"final_verdict\": {
    \"overall_winner\": \"{$product1 or $product2}\",
    \"final_scores\": {
      \"product1_total\": \"X.X/10\",
      \"product2_total\": \"X.X/10\"
    },
    \"victory_explanation\": \"Detailed explanation of why this product won\",
    \"margin_of_victory\": \"Close/Clear/Decisive\",
    \"key_deciding_factors\": [\"Top factors that determined the winner\"],
    \"runner_up_strengths\": \"What the losing product does well\",
    \"purchase_recommendation\": \"Clear guidance on which to buy when\",
    \"future_considerations\": \"How this recommendation might change over time\"
  },
  \"seo_optimized_sections\": {
    \"faq_for_featured_snippets\": [
      {
        \"question\": \"Which is better, {$product1} or {$product2}?\",
        \"answer\": \"Direct answer with key reasoning and recommendation\"
      },
      {
        \"question\": \"What's the difference between {$product1} and {$product2}?\",
        \"answer\": \"Key differences that matter most to buyers\"
      },
      {
        \"question\": \"Is {$product1} worth the extra money over {$product2}?\",
        \"answer\": \"Value analysis with clear recommendation\"
      },
      {
        \"question\": \"Should I buy {$product1} or wait for {$product2}?\",
        \"answer\": \"Timing and availability considerations\"
      }
    ],
    \"conclusion_comprehensive\": \"Detailed conclusion that reinforces the verdict with practical next steps for the reader\"
  }
}

Make this comparison so thorough and objective that readers feel completely confident in their choice and understand exactly why one product is better for their specific needs!";
    }

    /**
     * FONCTIONS UTILITAIRES POUR ENRICHIR LES PROMPTS
     */
    
    private static function get_appliance_science($appliance) {
        $science_explanations = [
            'air-fryer' => 'Air fryers work through rapid air circulation (convection) at high temperatures (350-400°F). The Maillard reaction creates browning and flavor development when proteins and sugars are exposed to dry heat. The key is moisture removal - patting food dry before cooking allows for maximum crispiness as water vapor doesn\'t interfere with browning. The circulating air removes steam constantly, creating a crispy exterior while maintaining moisture inside.',
            
            'instant-pot' => 'Pressure cooking raises the boiling point of water to 250°F (vs 212°F at normal pressure), allowing food to cook faster while retaining moisture. The pressurized environment breaks down tough fibers in meat and vegetables quickly. Steam pressure also forces flavors deeper into food. The sealed environment prevents nutrient loss that occurs with traditional boiling.',
            
            'slow-cooker' => 'Low, moist heat (175-200°F) breaks down collagen in tough cuts of meat into gelatin, creating tender, flavorful results. The long cooking time allows complex flavor development through chemical reactions. The sealed environment retains moisture and concentrates flavors. Enzymes in vegetables break down slowly, maintaining texture while developing sweetness.',
            
            'sous-vide' => 'Precise temperature control allows proteins to reach exact doneness without overcooking. Vacuum sealing prevents moisture loss and intensifies flavors. Lower temperatures (130-160°F) maintain protein structure while breaking down tough fibers. The sealed environment prevents oxidation and nutrient loss.',
        ];
        
        return $science_explanations[$appliance] ?? 'Explain the specific cooking science behind how this appliance achieves superior results compared to traditional methods.';
    }
    
    private static function get_emotion_hooks($keyword, $appliance) {
        $hooks = [
            'weeknight_tired' => "It's 6 PM, you're exhausted from work, and everyone's asking 'what's for dinner?' That familiar panic starts to set in...",
            'impressive_guests' => "Your friends are coming over in 2 hours, and you want to serve something that looks like you've been cooking all day...",
            'family_approval' => "You want to create that moment when everyone at the table stops talking and just enjoys the food...",
            'confidence_building' => "Remember the last time you tried cooking {$keyword} and it didn't turn out right? This time will be different...",
            'time_crunch' => "When you need restaurant-quality {$keyword} but only have {cooking_time} minutes to make it happen...",
            'health_conscious' => "Finally, a way to enjoy {$keyword} that doesn't make you feel guilty afterward..."
        ];
        
        return implode("\n", $hooks);
    }
    
    private static function get_dietary_science($dietary_tags) {
        if (empty($dietary_tags)) return '';
        
        $science = [
            'keto' => 'Ketogenic approach maximizes fat content while minimizing carbs to maintain ketosis. The high fat content provides satiety and energy.',
            'vegan' => 'Plant-based proteins provide complete amino acid profiles when properly combined. Focus on nutrient density and B12 considerations.',
            'gluten-free' => 'Alternative binding methods maintain texture without gluten. Focus on cross-contamination prevention and nutritional balance.',
            'low-carb' => 'Reduced carbohydrate content helps maintain stable blood sugar. Increased protein and healthy fats provide sustained energy.',
        ];
        
        $result = [];
        foreach (explode(',', $dietary_tags) as $tag) {
            $tag = trim($tag);
            if (isset($science[$tag])) {
                $result[] = $science[$tag];
            }
        }
        
        return implode(' ', $result);
    }
    
    private static function get_testing_methodology($category) {
        return "Professional testing methodology for {$category}:
- 6-month testing period with daily use simulation
- Standardized test conditions and measurement tools
- Multiple user profiles testing (beginner, intermediate, expert)
- Durability testing with accelerated wear simulation
- Performance benchmarking against industry standards
- Real-world scenario testing in various environments
- Long-term reliability assessment
- User experience documentation with video analysis
- Quantitative measurements using professional equipment
- Blind testing to eliminate brand bias";
    }
    
    private static function get_credibility_elements() {
        return "Credibility establishment elements:
- Specific testing time investment (hours/days/months)
- Measurement tools and methodology used
- Industry experience and qualifications
- Transparency about testing conditions
- Honest disclosure of limitations
- Regular update commitment
- Multiple perspectives included
- Bias prevention measures
- Independent verification where possible
- Clear differentiation between opinion and fact";
    }
    
    private static function get_comparison_frameworks($category) {
        return "Comparison framework for {$category}:
- Performance benchmarking with measurable metrics
- Value analysis considering total cost of ownership
- Feature comparison with real-world application assessment
- Build quality evaluation with durability predictions
- User experience analysis across skill levels
- Brand reputation and support quality assessment
- Future-proofing and upgrade path consideration
- Specific use case scenario testing
- Price-to-performance ratio calculation
- Long-term satisfaction prediction modeling";
    }
    
    private static function get_comparison_methodology() {
        return "Objective comparison methodology:
- Weighted scoring system based on user priorities
- Blind testing where possible to eliminate bias
- Multiple reviewer consensus for subjective elements
- Quantitative measurements for objective criteria
- Real-world usage scenario testing
- Long-term reliability assessment
- Total cost of ownership analysis
- User feedback integration from multiple sources
- Industry standard benchmarking
- Transparent scoring explanation and justification";
    }
    
    private static function get_scoring_framework() {
        return "Scoring framework (1-10 scale):
- Performance: 25% weight - Measured capabilities and real-world results
- Value: 20% weight - Price-to-benefit ratio and long-term ownership costs
- Features: 15% weight - Functionality breadth and innovation
- Usability: 15% weight - Learning curve and daily operation ease
- Build Quality: 15% weight - Materials, construction, expected longevity
- Support: 10% weight - Warranty, customer service, brand reputation
- Bonus factors: Additional points for exceptional innovation or value
- Penalty factors: Deductions for significant flaws or limitations
- Final score calculation with weighted averages
- Margin of victory classification (0-0.3 = tie, 0.3-0.7 = close, 0.7+ = decisive)";
    }
}