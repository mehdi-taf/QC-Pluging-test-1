# Quicky Cooking Content AI Plugin

![Plugin Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![WordPress Compatible](https://img.shields.io/badge/WordPress-5.0%2B-green.svg)
![PHP Version](https://img.shields.io/badge/PHP-7.4%2B-purple.svg)

## 🍳 Description

**Quicky Cooking Content AI** est un plugin WordPress révolutionnaire qui génère automatiquement du contenu culinaire optimisé SEO avec l'intelligence artificielle. Créez des recettes, guides d'achat, comparatifs et articles de blog en quelques clics !

## ✨ Fonctionnalités Principales

### 🤖 Génération de Contenu IA
- **Recettes d'appareils** - Créez des recettes optimisées pour Air Fryer, Instant Pot, Slow Cooker, etc.
- **Guides d'achat** - Générez des guides complets pour aider vos lecteurs à choisir
- **Comparatifs produits** - Créez des comparaisons détaillées entre appareils
- **Articles de blog** - Rédigez du contenu engageant sur la cuisine

### 🚀 Optimisation SEO Automatique
- Schema markup JSON-LD automatique
- Meta descriptions optimisées
- Titres SEO parfaits
- Tags automatiques intelligents
- Structure de contenu optimisée pour Google

### 💰 Monétisation Intégrée
- Zones d'affiliation automatiques
- Gestion des liens d'affiliation
- Tracking des clics
- Intégration Amazon Associates

### 🎨 Templates Frontend WOW
- Design moderne et responsive
- Animations fluides avec AOS
- Interface interactive (portions ajustables, étapes cochables)
- Mode impression optimisé
- Navigation flottante intelligente

## 🛠 Installation

### Méthode 1: Upload Manuel
1. Téléchargez le plugin
2. Uploadez le dossier dans `/wp-content/plugins/`
3. Activez le plugin dans l'admin WordPress
4. Allez dans **Quicky AI → Paramètres** pour configurer

### Méthode 2: Admin WordPress
1. Allez dans **Extensions → Ajouter**
2. Cherchez "Quicky Cooking Content AI"
3. Installez et activez
4. Configurez dans **Quicky AI → Paramètres**

## ⚙️ Configuration

### 1. Clé API OpenRouter
```
1. Allez sur https://openrouter.ai/keys
2. Créez un compte et générez une clé API
3. Copiez la clé (format: sk-or-v1-...)
4. Collez dans Quicky AI → Paramètres → Configuration API
```

### 2. Choix du Modèle IA
**Recommandés :**
- **Claude 3.5 Sonnet** - Qualité premium (~$0.015/génération)
- **Claude 3.5 Haiku** - Économique (~$0.001/génération)
- **Llama 3.1 70B** - Excellent rapport qualité/prix (~$0.0009/génération)

### 3. Personnalisation
- Ajustez le ton d'écriture (amical, professionnel, expert)
- Définissez la longueur du contenu
- Activez les optimisations SEO automatiques
- Personnalisez les prompts IA

## 🚀 Utilisation

### Créer une Recette
1. **Quicky AI → Créer du contenu**
2. Sélectionnez **"Recette d'appareil"**
3. Choisissez l'appareil (Air Fryer, Instant Pot, etc.)
4. Entrez le mot-clé principal (ex: "ailes de poulet")
5. Ajustez les paramètres (temps, portions, difficulté)
6. Cliquez **"Générer avec l'IA"**

### Créer un Guide d'Achat
1. **Quicky AI → Créer du contenu**
2. Sélectionnez **"Guide d'achat"**
3. Entrez la catégorie de produit
4. Définissez la gamme de prix
5. Spécifiez l'audience cible
6. **Générer** et le guide est créé !

### Gérer les Contenus
- **Quicky AI → Mes contenus** - Voir tous vos contenus générés
- Filtrez par type, statut, date
- Actions bulk (publier, dupliquer, supprimer)
- Système de favoris intégré

## 🎨 Customisation Frontend

### Templates Automatiques
Le plugin remplace automatiquement les templates WordPress pour les contenus générés :
- Template recette avec portions ajustables
- Template guide avec navigation sticky
- Template comparatif avec tableaux
- Design responsive sur tous devices

### Intégrations
- **Google Analytics** - Tracking automatique
- **Schema.org** - Données structurées
- **AMP** - Compatible Accelerated Mobile Pages
- **Yoast SEO** - Meta données automatiques

## 📊 Analytics & Performance

### Métriques Incluses
- Nombre de contenus générés
- Coût API estimé
- Score SEO moyen
- Taux de conversion affiliation

### Dashboard Avancé
- Statistiques en temps réel
- Graphiques de performance
- Recommandations d'optimisation
- Logs d'activité détaillés

## 🛡️ Sécurité

- Vérification nonce sur tous les formulaires
- Sanitization de toutes les entrées utilisateur
- Validation des permissions WordPress
- Chiffrement des clés API
- Audit trails complets

## 🔧 Développeurs

### Hooks Disponibles
```php
// Avant génération de contenu
do_action('quicky_before_generation', $content_type, $data);

// Après génération réussie
do_action('quicky_after_generation', $post_id, $content_data);

// Modifier le prompt IA
apply_filters('quicky_ai_prompt', $prompt, $content_type);

// Personnaliser le template
apply_filters('quicky_template_path', $template, $content_type);
```

### Structure des Fichiers
```
quicky-cooking-ai/
├── quicky-cooking-ai.php          # Plugin principal
├── includes/
│   ├── class-quicky-ai-connector.php    # API IA
│   ├── class-quicky-meta-boxes.php      # Interface admin
│   ├── class-quicky-templates.php       # Templates frontend
│   ├── quicky-ai-settings.php           # Paramètres
│   ├── quicky-ai-create-page.php        # Génération contenu
│   └── quicky-ai-list-page.php          # Liste contenus
├── assets/
│   ├── css/
│   │   ├── admin.css                     # Styles admin
│   │   └── quicky-template.css           # Styles frontend
│   └── js/
│       ├── admin.js                      # Scripts admin
│       └── quicky-template.js            # Scripts frontend
└── README.md
```

## 📋 Prérequis

- **WordPress** 5.0+
- **PHP** 7.4+
- **MySQL** 5.6+
- **Clé API OpenRouter** (gratuite avec limits)
- **Connexion internet** pour appels API

## 🆘 Support

### Documentation
- [Guide d'installation détaillé](https://quickycooking.com/docs/installation)
- [Tutoriels vidéo](https://quickycooking.com/tutorials)
- [FAQ complète](https://quickycooking.com/faq)

### Assistance
- **Email** : support@quickycooking.com
- **Forum** : [Community Support](https://quickycooking.com/forum)
- **Discord** : [Serveur développeurs](https://discord.gg/quickycooking)

## 🐛 Problèmes Courants

### "API non configurée"
```
Solution: Vérifiez que votre clé OpenRouter est correcte
Format attendu: sk-or-v1-xxxxxxxxxxxx
```

### Génération échoue
```
Vérifications:
1. Clé API valide et avec crédits
2. Connexion internet stable  
3. Pas de plugins conflictuels
4. Logs dans Quicky AI → Paramètres → Debug
```

### Templates ne s'affichent pas
```
Causes possibles:
1. Thème non compatible
2. Cache à vider
3. Permaliens à rafraîchir
```

## 🔄 Changelog

### v1.0.0 (2025-01-XX)
- 🎉 Version initiale
- ✨ Génération recettes, guides, comparatifs
- 🚀 SEO automatique avec schema markup
- 💰 Système d'affiliation intégré
- 🎨 Templates frontend avec animations
- 📊 Dashboard analytics complet

## 🤝 Contribution

Nous accueillons les contributions ! 

### Comment Contribuer
1. Forkez le repo
2. Créez une branche feature (`git checkout -b feature/AmazingFeature`)
3. Committez (`git commit -m 'Add AmazingFeature'`)
4. Push (`git push origin feature/AmazingFeature`)
5. Ouvrez une Pull Request

### Guidelines
- Suivez les standards WordPress Coding
- Ajoutez des tests pour nouvelles features
- Documentez votre code
- Respectez la structure existante

## 📄 License

Ce plugin est sous licence **GPL v2 ou plus récente**.

```
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
```

## 🌟 Crédits

### Technologies Utilisées
- **Claude AI** par Anthropic
- **OpenRouter API** pour l'IA
- **WordPress APIs** natives
- **AOS Library** pour animations
- **Chart.js** pour graphiques

### Remerciements
- L'équipe Anthropic pour Claude
- La communauté WordPress
- Tous nos beta testeurs
- Les contributeurs open source

---

**Made with 💖 by [Quicky Cooking Team](https://quickycooking.com)**

*Transformez votre blog culinaire avec l'IA ! 🚀*